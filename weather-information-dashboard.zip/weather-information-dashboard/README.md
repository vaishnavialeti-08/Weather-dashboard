# SkyCast – Weather Information Dashboard

A responsive weather dashboard built for a beginner frontend internship assignment using **HTML, CSS and vanilla JavaScript**.

## Features

### Required features
- Search for a city
- Current temperature and weather condition
- Humidity and wind speed
- Weather condition icon
- Loading state while data is fetched
- Error handling for unknown cities and failed requests
- Responsive layout for desktop, tablet and mobile

### Bonus features
- Five-day weather forecast
- Current-location weather (requires location permission and HTTPS or localhost)
- Dark mode (preference is saved in local storage)
- Recent searches (saved in local storage)

## Technology and API

- HTML5
- CSS3 (Grid, Flexbox, media queries)
- Vanilla JavaScript (Fetch API, async/await, DOM)
- [Open-Meteo Forecast API](https://open-meteo.com/en/docs)
- [Open-Meteo Geocoding API](https://open-meteo.com/en/docs/geocoding-api)

No API key is required for the public Open-Meteo endpoints used in this learning project. Review the provider's current terms and attribution requirements before public/commercial use.

## Project structure

```text
weather-information-dashboard/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
```

## Run locally

1. Download or clone this repository.
2. Open the project folder in VS Code.
3. Start a local server. For example, install the **Live Server** extension and choose **Go Live**.
4. Open the local URL shown by Live Server.
5. Search for a city, such as Hyderabad, Mumbai, London or Tokyo.

You can also use another local static web server. A local server is recommended because browser geolocation works in secure contexts such as `localhost` and HTTPS.

## How it works

1. The user enters a city name.
2. `getCoordinates()` calls the Open-Meteo Geocoding API to find its latitude and longitude.
3. `getWeather()` sends those coordinates to the Forecast API.
4. `renderWeather()` updates the current weather, highlights and five-day forecast in the page.
5. The recent city list and theme preference are stored in browser `localStorage`.

## Important JavaScript concepts used

- `fetch()` to request API data
- `async` / `await` to handle asynchronous requests
- `try` / `catch` for error handling
- `URLSearchParams` to build API query parameters safely
- DOM selection and event listeners
- Array methods such as `map`, `filter` and `slice`
- `localStorage` to preserve small user preferences

## Test checklist

- [ ] Search for a valid city
- [ ] Search for a misspelled or invalid city
- [ ] Check temperature, condition, humidity and wind speed
- [ ] Confirm the five-day forecast appears
- [ ] Test the current-location button after granting permission
- [ ] Deny location permission and confirm the message is understandable
- [ ] Toggle dark mode and refresh the page
- [ ] Search for several cities and test recent-search buttons
- [ ] Clear recent searches
- [ ] Test the layout at mobile and desktop widths

## Deployment (GitHub Pages)

1. Create a GitHub repository, for example `weather-information-dashboard`.
2. Upload `index.html`, `style.css`, `script.js`, `README.md` and the `assets` folder.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. Copy the live URL shown in the Pages section.

## Suggested project report

**Title:** Weather Information Dashboard

**Objective:** To develop a responsive web application that allows users to search for a city and view current weather information using a public weather API.

**Tools used:** HTML, CSS, JavaScript, Open-Meteo API and Visual Studio Code.

**Implementation summary:** The application converts a city name into geographic coordinates using the Geocoding API. It then requests current and daily weather data from the Forecast API and displays the response dynamically. Loading feedback and error messages improve usability. The optional features include a five-day forecast, current-location weather, dark mode and recent searches.

**Conclusion:** This project demonstrates the use of HTML for structure, CSS for responsive presentation, and JavaScript Fetch API for retrieving and displaying live data from a public API.

## Before your demo

Understand the flow from city search → geocoding → weather request → DOM update. Be prepared to explain the Fetch API, `async/await`, error handling, and how the app handles a location permission denial.
