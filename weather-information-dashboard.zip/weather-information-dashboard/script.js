const API_BASE = "https://api.open-meteo.com/v1/forecast";
const GEOCODING_BASE = "https://geocoding-api.open-meteo.com/v1/search";

const $ = (id) => document.getElementById(id);
const searchForm = $("searchForm");
const cityInput = $("cityInput");
const searchButton = $("searchButton");
const statusMessage = $("statusMessage");

const weatherDescriptions = {
  0: ["Clear sky", "☀️"], 1: ["Mainly clear", "🌤️"], 2: ["Partly cloudy", "⛅"],
  3: ["Overcast", "☁️"], 45: ["Fog", "🌫️"], 48: ["Rime fog", "🌫️"],
  51: ["Light drizzle", "🌦️"], 53: ["Drizzle", "🌦️"], 55: ["Dense drizzle", "🌧️"],
  56: ["Freezing drizzle", "🌧️"], 57: ["Heavy freezing drizzle", "🌧️"],
  61: ["Light rain", "🌦️"], 63: ["Rain", "🌧️"], 65: ["Heavy rain", "🌧️"],
  66: ["Freezing rain", "🌧️"], 67: ["Heavy freezing rain", "🌧️"],
  71: ["Light snow", "🌨️"], 73: ["Snow", "🌨️"], 75: ["Heavy snow", "❄️"],
  77: ["Snow grains", "🌨️"], 80: ["Rain showers", "🌦️"], 81: ["Rain showers", "🌧️"],
  82: ["Heavy rain showers", "⛈️"], 85: ["Snow showers", "🌨️"], 86: ["Heavy snow showers", "❄️"],
  95: ["Thunderstorm", "⛈️"], 96: ["Thunderstorm with hail", "⛈️"], 99: ["Severe thunderstorm", "⛈️"]
};

let recentCities = [];
try { recentCities = JSON.parse(localStorage.getItem("skycastRecent") || "[]"); } catch { recentCities = []; }

function setStatus(message = "", isError = false) {
  statusMessage.textContent = message;
  statusMessage.classList.toggle("error", isError);
}
function weatherInfo(code) {
  return weatherDescriptions[code] || ["Weather conditions", "🌤️"];
}
function formatTime(value, timezone) {
  if (!value) return "--:--";
  return new Intl.DateTimeFormat("en", { hour: "2-digit", minute: "2-digit", hour12: true, timeZone: timezone }).format(new Date(value));
}
function dayName(dateString, index) {
  if (index === 0) return "Today";
  return new Intl.DateTimeFormat("en", { weekday: "short", timeZone: "UTC" }).format(new Date(`${dateString}T12:00:00Z`));
}
function setLoading(isLoading) {
  searchButton.disabled = isLoading;
  searchButton.textContent = isLoading ? "Loading…" : "Search";
}
async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Request failed (${response.status}). Please try again.`);
  return response.json();
}
async function getCoordinates(city) {
  const data = await fetchJson(`${GEOCODING_BASE}?name=${encodeURIComponent(city)}&count=1&language=en&format=json`);
  if (!data.results || !data.results.length) throw new Error("City not found. Check the spelling and try again.");
  return data.results[0];
}
async function getWeather(latitude, longitude) {
  const params = new URLSearchParams({
    latitude, longitude,
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,wind_speed_10m",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset",
    timezone: "auto",
    forecast_days: "5",
    wind_speed_unit: "kmh"
  });
  return fetchJson(`${API_BASE}?${params.toString()}`);
}
function renderWeather(place, data) {
  const current = data.current;
  const daily = data.daily;
  const [description, icon] = weatherInfo(current.weather_code);
  const high = Math.round(daily.temperature_2m_max[0]);
  const low = Math.round(daily.temperature_2m_min[0]);

  $("locationName").textContent = [place.name, place.admin1, place.country].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(", ");
  $("currentDate").textContent = new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric", timeZone: data.timezone }).format(new Date());
  $("currentIcon").textContent = icon;
  $("temperature").textContent = Math.round(current.temperature_2m);
  $("condition").textContent = description;
  $("feelsLike").textContent = `Feels like ${Math.round(current.apparent_temperature)}°C`;
  $("highLow").textContent = `${high}° / ${low}°`;
  $("sunrise").textContent = formatTime(daily.sunrise[0], data.timezone);
  $("sunset").textContent = formatTime(daily.sunset[0], data.timezone);

  $("humidity").textContent = current.relative_humidity_2m;
  $("humidityBar").style.width = `${Math.max(0, Math.min(100, current.relative_humidity_2m))}%`;
  $("wind").textContent = Math.round(current.wind_speed_10m);
  $("cloud").textContent = current.cloud_cover;
  $("feelsMetric").textContent = Math.round(current.apparent_temperature);
  $("detailDate").textContent = "LIVE";

  $("forecastList").innerHTML = daily.time.map((date, index) => {
    const [label, dayIcon] = weatherInfo(daily.weather_code[index]);
    return `<div class="forecast-day">
      <span class="day-name">${dayName(date, index)}</span>
      <span class="day-icon" aria-hidden="true">${dayIcon}</span>
      <strong>${Math.round(daily.temperature_2m_max[index])}°<span class="low">${Math.round(daily.temperature_2m_min[index])}°</span></strong>
      <span class="day-desc">${label}</span>
    </div>`;
  }).join("");
}
function saveRecent(place) {
  const label = place.name;
  recentCities = [label, ...recentCities.filter((city) => city.toLowerCase() !== label.toLowerCase())].slice(0, 5);
  localStorage.setItem("skycastRecent", JSON.stringify(recentCities));
  renderRecent();
}
function renderRecent() {
  const list = $("recentList");
  if (!recentCities.length) {
    list.innerHTML = '<span class="empty-recent">Your searched cities will appear here.</span>';
    return;
  }
  list.innerHTML = "";
  recentCities.forEach((city) => {
    const button = document.createElement("button");
    button.className = "recent-chip";
    button.type = "button";
    button.textContent = city;
    button.addEventListener("click", () => searchCity(city));
    list.appendChild(button);
  });
}
async function searchCity(city) {
  if (!city.trim()) return;
  setLoading(true);
  setStatus("Finding the latest weather…");
  try {
    const place = await getCoordinates(city.trim());
    const weather = await getWeather(place.latitude, place.longitude);
    renderWeather(place, weather);
    saveRecent(place);
    cityInput.value = "";
    setStatus(`Weather updated for ${place.name}.`);
  } catch (error) {
    setStatus(error.message || "Something went wrong. Please try again.", true);
  } finally {
    setLoading(false);
  }
}
searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  searchCity(cityInput.value);
});
$("locationButton").addEventListener("click", () => {
  if (!navigator.geolocation) {
    setStatus("Location is not supported by this browser.", true);
    return;
  }
  setStatus("Requesting your location…");
  navigator.geolocation.getCurrentPosition(async ({ coords }) => {
    setLoading(true);
    try {
      const weather = await getWeather(coords.latitude, coords.longitude);
      const reverse = await fetchJson(`${GEOCODING_BASE}?latitude=${coords.latitude}&longitude=${coords.longitude}&count=1&language=en&format=json`);
      const place = reverse.results?.[0] || { name: "Your location", country: "" };
      renderWeather(place, weather);
      saveRecent(place);
      setStatus("Weather updated for your current location.");
    } catch (error) {
      setStatus(error.message || "Unable to load weather for your location.", true);
    } finally { setLoading(false); }
  }, (error) => {
    const message = error.code === 1 ? "Location permission was denied. You can search for a city instead." : "Unable to get your location. Please search for a city.";
    setStatus(message, true);
  }, { enableHighAccuracy: false, timeout: 10000 });
});
$("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  $("themeToggle").textContent = dark ? "☀" : "☾";
  $("themeToggle").setAttribute("aria-label", dark ? "Switch to light theme" : "Switch to dark theme");
  localStorage.setItem("skycastTheme", dark ? "dark" : "light");
});
$("clearRecent").addEventListener("click", () => {
  recentCities = [];
  localStorage.removeItem("skycastRecent");
  renderRecent();
});
if (localStorage.getItem("skycastTheme") === "dark") {
  document.body.classList.add("dark");
  $("themeToggle").textContent = "☀";
}
renderRecent();
// Load a useful default city when the page first opens.
searchCity("Hyderabad");
